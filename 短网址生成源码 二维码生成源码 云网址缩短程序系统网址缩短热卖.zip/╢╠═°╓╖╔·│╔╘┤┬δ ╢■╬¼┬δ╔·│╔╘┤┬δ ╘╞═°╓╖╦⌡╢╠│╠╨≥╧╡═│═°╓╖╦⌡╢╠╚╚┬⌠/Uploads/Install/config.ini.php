<?php
if (!defined('THINK_PATH')) exit();
return array(
	'SOFT_NAME' =>'短网址',
	'SOFT_HOMEPAGE' =>'www.pengyong.info',
	'SOFT_AUTHOR' =>'将军',
	'SOFT_CONTRACT' =>'634150845',
	'SOFT_VERSION'=>'3.0 运营版',
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'~dbhost~',
	'DB_NAME'=>'~dbname~',
	'DB_USER'=>'~dbuser~',
	'DB_PWD'=>'~dbpwd~',
	'DB_PORT'=>'3306',
	'DB_PREFIX'=>'~dbprefix~',
	'DB_CHARSET'=>'~dblang~',
	'DEFAULT_CHARSET'=>'~dblang~',
	'COOKIE_PREFIX'=>'~dbcookie~'.'_', 
	);
?>