## Superspeed
Superspeed.sh with updated server lists.

## Usage
```
bash <(curl -Lso- https://git.io/superspeed)
```

[查看全部节点列表](https://git.io/superspeedList)

![测速图](https://i.loli.net/2019/12/23/H8WtjGTgDqVsUaL.jpg)

---

Modified from Oldking's script. Original Info:
- Description: Test your server's network with Speedtest to China
- Copyright (C) 2018 Oldking <oooldking@gmail.com>
