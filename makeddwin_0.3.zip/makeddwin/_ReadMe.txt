网址：nat.ee
批处理：荣耀&制作 QQ:1800619
批处理脚本，均由本人原创编写。
本批处理工具仅适合Windows 7 sp1 以上的系统使用！
注意：不能放在带有空格路径的目录，否则出错。
TG交流群：https://t.me/nat_ee
如在使用中有任何问题或者建议，欢迎加入交流。
----------------------------------------------
更新：
2020/8/31 ----0.3 优化批处理代码。
2020/8/12 ----0.2 优化批处理代码。
2020/8/10 ----0.1 添加pigz替换7z,更快压缩gz文件。

说明：
【使用前，请把所需的文件放进相应文件夹！】
目录结构：
bin 文件夹，存放用来制作的依赖程序和文件。
iso 文件夹，存放Windows ISO 系统镜像(只能放1个)
packages 文件夹，存放Windows 补丁文件
driver 文件夹，存放其他驱动文件
virtio 文件夹，存放KVM virtio ISO 驱动镜像(只能放1个)
vhd 文件夹，存放 .vhd格式 虚拟硬盘(只能放1个)
export 文件夹，输出生成的.gz、.wim、和解压的.vhd文件。
注意，只能放一个的目录务必按要求，因为放多个会导致脚本无法判断。

步骤1：使用vhd.cmd批处理，生成一个大小20-30G左右的虚拟硬盘
生成后的虚拟硬盘文件会在vhd目录，虚拟硬盘大小视你安装系统后硬盘体积还剩多少。
一般安装系统后，虚拟硬盘最低要剩空闲有1G左右，后期可以再创建对应体积的虚拟硬盘作调整。

步骤2：使用install.cmd批处理，选择刚才创建的已挂载的虚拟硬盘分区，自行查看[我的电脑]，你虚拟硬盘生成多少G的分区，就选择那个分区，进行下一步安装系统等其他操作。

步骤3：使用dd.cmd批处理，对已经完成制作的.vhd虚拟硬盘文件进行压缩成可DD的文件或者wim文件。
压缩完成后，别忘了测试文件的完整性检查，否则是一个损坏的数据文件是无法使用的！
生成的.gz文件，可以在Linux系统下DD为此系统。
生成的.wim文件，可以在WinPE中安装到实体机系统，又或者添加生成为一个iso文件。
(注意，压缩比较慢通常是几十分钟不等，电脑CPU配置越高越快！)

关于创建的VHD虚拟硬盘，假如你的VPS为20G硬盘的，那么你创建的虚拟硬盘不要大于，但可以小于。
----------------------------------------------
其他说明：
..\bin\other\ 目录结构

所有无人值守文件(unattend目录).xml
默认账户：Administrator
默认密码：nat.ee
可自行编辑。

SetupComplete.cmd
执行静态IP和添加一些激活程序在安装部署时执行。

3389.cmd
用于在机子上一键修改远程桌面端口和用户密码。

----------------------------------------------
更多自定义操作：

VirtualBox
虚拟机----在里面挂载vhd虚拟硬盘进行测试是否安装正常。
https://www.virtualbox.org/

wsusoffline
下载系统的离线补丁
https://www.wsusoffline.net/

Dism++
自定义系统各项功能
http://www.chuyu.me/zh-Hans/index.html

微软官方离线补丁下载
http://www.catalog.update.microsoft.com/home.aspx

全球最全驱动包下载
http://driveroff.net

Windows虚拟化KVM驱动
https://fedorapeople.org/groups/virt/virtio-win/direct-downloads/archive-virtio/

Windows虚拟化XEN驱动
https://docs.aws.amazon.com/AWSEC2/latest/WindowsGuide/xen-drivers-overview.html
https://s3.amazonaws.com/ec2-windows-drivers-downloads/AWSPV/Latest/AWSPVDriver.zip
----------------------------------------------
依赖程序文件来源：
7z.exe
7z.dll
用于：压缩、解压、测试
官网：https://www.7-zip.org/

imagex.exe
bcdboot.exe
用于：安装、压缩、引导
官网：https://docs.microsoft.com/en-us/windows-hardware/get-started/adk-install

pigz.exe
用于：多线程压缩GZ文件
官网：https://github.com/madler/pigz https://binaries.przemoc.net/
