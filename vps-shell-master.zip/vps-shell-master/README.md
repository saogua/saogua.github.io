# vps-shell
收集一些自用的shell脚本，适用于懒人使用。

## 新增一键tcp加速
包括锐速及bbr暴力版等

wget https://raw.githubusercontent.com/rptec/vps-shell/master/tcp.sh && sh tcp.sh


## VPS测试
测试VPS基础信息，以及下载速度

wget https://raw.githubusercontent.com/rptec/vps-shell/master/bench.sh && sh bench.sh

跑分

wget https://raw.githubusercontent.com/rptec/vps-shell/master/unixbench.sh && sh unixbench.sh

## Linux安装桌面

给你的linux装个桌面，适用于centos系统

wget https://raw.githubusercontent.com/rptec/vps-shell/master/xwindow.sh && sh xwindow.sh
## SS 一键包
一键安装shadowsocks服务器端，python版本，适用一切linux系统

wget https://raw.githubusercontent.com/rptec/vps-shell/master/shadowsocks.sh && sh shadowsocks.sh

## SSR 一键包
wget https://raw.githubusercontent.com/rptec/vps-shell/master/shadowsocksR.sh && sh shadowsocksR.sh


## 锐速一键包

一键安装锐速破解全功能版，不支持openvz架构

wget https://raw.githubusercontent.com/rptec/vps-shell/master/serverspeeder.sh && sh serverspeeder.sh




