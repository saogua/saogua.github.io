<?php exit;
	db_delete('post_search', array('pid'=>$pid));
?>