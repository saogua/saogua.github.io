<?php exit;

$fuparr = param('fup', array(0));

?>