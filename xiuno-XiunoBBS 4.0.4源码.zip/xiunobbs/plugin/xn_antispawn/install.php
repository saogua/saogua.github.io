<?php

/*
	Xiuno BBS 4.0 插件实例：广告插件安装
	admin/plugin-install-xn_ad.htm
*/

!defined('DEBUG') AND exit('Forbidden');

setting_set('xn_anti_spam_key', xn_rand(16));

?>