!isset($conf['nav_2_on']) AND $conf['nav_2_on'] = 0;
!isset($conf['nav_2_bbs_on']) AND $conf['nav_2_bbs_on'] = 0; // 是否开启导航 bbs
!isset($conf['nav_2_forum_list_pc_on']) AND $conf['nav_2_forum_list_pc_on'] = 0;
!isset($conf['nav_2_forum_list_mobile_on']) AND $conf['nav_2_forum_list_mobile_on'] = 0;

$conf['logo_pc_url'] = 'plugin/xn_nav_2/view/img/logo_pc.png';