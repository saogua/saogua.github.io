var lang = {
	'warning': '警告',
	'tips_title': '提示：',
	'confirm': '确定',
	'confirm_title': '请确认以下信息：',
	'confirm_delete': '确定删除吗？',
	'close': '关闭',
	'yes': '是',
	'no': '否',
	'open': '打开',
	'close': '关闭',
	// hook lang_zh_cn_bbs_js.htm
};