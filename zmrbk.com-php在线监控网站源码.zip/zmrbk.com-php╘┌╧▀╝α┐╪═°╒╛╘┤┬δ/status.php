<?php
/*
 * 服务器状态监控
 * www.zmrbk.com
 */
header('Content-type:text/html;charset=utf-8');
include './smtp/class.smtp.php';
include './smtp/class.phpmailer.php';
function sendmail($subject = '',$body = '') {
    date_default_timezone_set('Asia/Shanghai');//设定时区东八区
    $mail             = new PHPMailer(); //new一个PHPMailer对象出来
    // $body            = eregi_replace("[\]",'',$body); //对邮件内容进行必要的过滤
    $mail->CharSet ="UTF-8";//设定邮件编码，默认ISO-8859-1，如果发中文此项必须设置，否则乱码
    $mail->IsSMTP(); // 设定使用SMTP服务
    $mail->SMTPAuth   = true;                  // 启用 SMTP 验证功能
    $mail->Host       = 'smtp.exmail.qq.com';      // SMTP 服务器
    $mail->Port       = 25;   // SMTP服务器的端口号
    $mail->Username   = '123456@qq.com';  // SMTP服务器用户名
    $mail->Password   = 'pass123456';            // SMTP服务器密码
    $mail->SetFrom('123456@qq.com','Status');
    $mail->AddReplyTo('123456@qq.com','Status');
    $mail->Subject    = $subject;
    $mail->AltBody    = 'To view the message, please use an HTML compatible email viewer!'; // optional, comment out and test
    $mail->MsgHTML($body);
    $address = 'admin@admin.com';	//接收邮箱
    $mail->AddAddress($address, '');
    //$mail->AddAttachment("images/phpmailer.gif");      // attachment  附件
    //$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment
    if(!$mail->Send()) {
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    } else {
         // echo "Message sent!恭喜，邮件发送成功！";
    }
}
//check server status
function checkServerSatatus($ip) {
	$str = null;
	$fp = @fsockopen($ip,80,$errno,$errstr,10);

	if (!$fp) {
		return false;
	} else {
		fclose($fp);
		return true;
	}
}
$server_ip_list = array(
							'220.181.57.216',
							'221.204.173.200',
							'173.194.127.83'
						);
?>
<!doctype html>
<html lang="zh_CN">
<head>
	<meta charset="UTF-8">
	<title>追梦服务器状态监控-by zmrbk.com</title>
	<style>
	* {
		margin: 0px;
		padding: 0px;
	}
	body {
		font-family: "Microsoft yahei",Arial;
		font-size:14px;
	}
	header {
		height: 40px;
		background-color: #2e2e2e;
		width: 100%;
		line-height: 35px;
	}
	header > h3 {
		color: #fff;
		margin-left: 20px;
	}
	footer {
		text-align: center;
	}
	a {
		color: #424242;
		text-decoration: none;
	}
	.wrap {
		height: auto;
		zoom:1;
		overflow: auto;
		max-width: 500px;
		width: 100%;
		margin: 50px auto;
	}
	.table {
		border-collapse: collapse;
		border: 1px solid #eee;
		width: 100%;
	}
	tr,td{
		color: #424242;
		border-collapse: collapse;
		border: 1px solid #F0F0F0;
		height: 30px;
		text-align: center;
	}
	tr:nth-child(2n+1) {
		background-color: #F7F8FC;
	}
	tr:hover {
		background-color: #F7F8FC;
	}
	.online,.offline {
		height: 20px;
		background-color: #2ECC71;
		width: 40px;
		margin: 0px auto;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		color: #fff;
	}
	.offline {
		width: 50px;
		background-color: #E74C3C;
	}
	</style>
</head>
<body>
	<header>
		<h3>追梦网站在线状态监控</h3>
	</header>
	<div class="wrap">
		<table class="table">
			<tbody>
				<tr><td>序号</td><td>地址</td><td>目标</td><td>状态</td></tr>
				<?php
					$i = 0;
					foreach ($server_ip_list as $key => $val) {
						$api = file_get_contents('http://ip.taobao.com/service/getIpInfo.php?ip='.$server_ip_list[$key].'');
						$json = json_decode($api);
						$result = $json->data;

						$i++;
						if (checkServerSatatus($server_ip_list[$key])) {
							echo "<tr><td>{$i}</td><td>{$result->country}{$result->region}{$result->city}</td><td>{$server_ip_list[$key]}</td><td><div class=\"online\">在线</div></td></tr>";
						} else {
							echo "<tr><td>{$i}</td><td>{$result->country}{$result->region}{$result->city}</td><td>{$server_ip_list[$key]}</td><td><div class=\"offline\">不在线</div></td></tr>";
							$subject = "您的服务器 {$server_ip_list[$key]} 无法访问！";
							$body = "您的服务器{$server_ip_list[$key]} 无法访问，此邮件根据你设置的监控频率发送，当服务器恢复正常邮件自动停止发送！<br />Power By www.zmrbk.com";
							sendmail($subject,$body);
						}
					}

				 ?>
			</tbody>
		</table>
	</div>
	<footer>
		<p>Power By <a href="http://www.zmrbk.com" target="_blank">zmrbk.com</a>-Auto By <a href="https://www.cxsir.com/"  target="_blank" rel="nofollow">cxsir</a>-<script src="http://s5.cnzz.com/stat.php?id=3909316&web_id=3909316" language="JavaScript"></script></p>
	</footer>
</body>
</html>
